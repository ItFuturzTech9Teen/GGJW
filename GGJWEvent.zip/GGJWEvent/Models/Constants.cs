﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GGJWEvent.Models
{
    public class Constants
    {

        //public static string APP_URL = "http://test.eyesdeal.com";
        //public static string APP_URL = "http://test.eyesdeal.com";
        public static string FileTypeUser = "User";
        public static string FileTypeExhibitorBanner = "ExhibitorBanner";
        public static string FileTypeDailyDraw = "DailyDraw";
        public static string FileTypeMegaDraw = "MegaDraw";
        public static string FileTypeVisitor = "Visitor";
        public static string FileTypeExhibitor = "Exhibitor";

    }
}