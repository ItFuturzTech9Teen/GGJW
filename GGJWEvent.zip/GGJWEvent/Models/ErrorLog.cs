﻿namespace GGJWEvent.Models
{
    internal class ErrorLog
    {
    }
}